﻿/**
* 4/24/23
* CSC 153
* Max Cayton
* This program simulates a car's acceleration and brakes.
*/
using System;
using CarLibrary;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        // Create The Car Object
        Car car = new Car(1964, "Ford");

        public Form1()
        {
            InitializeComponent();
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            car.Accelerate();
            // Display Current Speed
            speedTextBox.Text = car.Speed.ToString();
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            car.Brake();
            // Display Current Speed
            speedTextBox.Text = car.Speed.ToString();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
