﻿/**
* 2/28/2023
* CSC 153
* Max Cayton
* This program calculates the total pay for a salary of pennies that doubles each day.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        int daysCount;
        int penniesCount = 1;
        decimal totalPay = 0.0m;
        public Form1()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {

            // Gather Input and perform calculations
            int.TryParse(daysTextBox.Text,out daysCount);

            for (int i = 0; i < daysCount; i++)
            {
                if (i != 0)
                {
                    penniesCount = penniesCount * 2;
                }

                totalPay += (0.01m * penniesCount);
            }

            penniesTextBox.Text = totalPay.ToString("c");

            // Reset Variables & Input Box
            daysCount = 0;
            penniesCount = 1;
            totalPay = 0.0m;
            daysTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}