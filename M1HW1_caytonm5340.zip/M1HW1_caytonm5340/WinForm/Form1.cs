﻿/**
* 1/16/2023
* CSC 153
* Max Cayton
* This program collects name information from the user, formats it based on the formatting method the user selects, then outputs it in a textbox.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class nameFormatter : Form
    {
        private string firstName = "";
        private string middleName = "";
        private string lastName = "";
        private string title = "";
        private string formattedName = "";

        public nameFormatter()
        {
            InitializeComponent();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {

            firstName = firstNameForm.Text;
            middleName = middleNameForm.Text;
            lastName = lastNameForm.Text;
            title = titleForm.Text;

            // Clear Boxes to Communicate the Collection of Input to the User
            firstNameForm.Text = "";
            middleNameForm.Text = "";
            lastNameForm.Text = "";
            titleForm.Text = "";

        }

        private void formatOption1_Click(object sender, EventArgs e)
        {
            formattedName = title+" "+firstName+" "+middleName+" "+lastName;
            formatNameForm.Text = formattedName;
        }

        private void formatOption2_Click(object sender, EventArgs e)
        {
            formattedName = firstName + " " + middleName + " " + lastName;
            formatNameForm.Text = formattedName;
        }

        private void formatOption3_Click(object sender, EventArgs e)
        {
            formattedName = firstName + " " + lastName;
            formatNameForm.Text = formattedName;
        }

        private void formatOption4_Click(object sender, EventArgs e)
        {
            formattedName = lastName + ", " + firstName + " " + middleName + ", " + title;
            formatNameForm.Text = formattedName;
        }

        private void formatOption5_Click(object sender, EventArgs e)
        {
            formattedName = lastName + ", " + firstName + " " + middleName;
            formatNameForm.Text = formattedName;
        }

        private void formatOption6_Click(object sender, EventArgs e)
        {
            formattedName = lastName + ", " + firstName;
            formatNameForm.Text = formattedName;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
