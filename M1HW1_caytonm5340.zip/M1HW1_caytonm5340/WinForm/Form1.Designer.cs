﻿
namespace WinForm
{
    partial class nameFormatter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterButton = new System.Windows.Forms.Button();
            this.nameInputGroup = new System.Windows.Forms.GroupBox();
            this.titleLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.titleForm = new System.Windows.Forms.TextBox();
            this.lastNameForm = new System.Windows.Forms.TextBox();
            this.middleNameForm = new System.Windows.Forms.TextBox();
            this.firstNameForm = new System.Windows.Forms.TextBox();
            this.nameOutputGroup = new System.Windows.Forms.GroupBox();
            this.option6Label = new System.Windows.Forms.Label();
            this.option5Label = new System.Windows.Forms.Label();
            this.option4Label = new System.Windows.Forms.Label();
            this.option3Label = new System.Windows.Forms.Label();
            this.option2Label = new System.Windows.Forms.Label();
            this.option1Label = new System.Windows.Forms.Label();
            this.formattedNameLabel = new System.Windows.Forms.Label();
            this.formatOption6 = new System.Windows.Forms.Button();
            this.formatOption5 = new System.Windows.Forms.Button();
            this.formatOption4 = new System.Windows.Forms.Button();
            this.formatOption3 = new System.Windows.Forms.Button();
            this.formatOption2 = new System.Windows.Forms.Button();
            this.formatOption1 = new System.Windows.Forms.Button();
            this.formatNameForm = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.nameInputGroup.SuspendLayout();
            this.nameOutputGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // enterButton
            // 
            this.enterButton.Location = new System.Drawing.Point(155, 251);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(75, 32);
            this.enterButton.TabIndex = 5;
            this.enterButton.Text = "Enter";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            // 
            // nameInputGroup
            // 
            this.nameInputGroup.Controls.Add(this.titleLabel);
            this.nameInputGroup.Controls.Add(this.lastNameLabel);
            this.nameInputGroup.Controls.Add(this.middleNameLabel);
            this.nameInputGroup.Controls.Add(this.firstNameLabel);
            this.nameInputGroup.Controls.Add(this.titleForm);
            this.nameInputGroup.Controls.Add(this.lastNameForm);
            this.nameInputGroup.Controls.Add(this.middleNameForm);
            this.nameInputGroup.Controls.Add(this.firstNameForm);
            this.nameInputGroup.Controls.Add(this.enterButton);
            this.nameInputGroup.Location = new System.Drawing.Point(13, 12);
            this.nameInputGroup.Name = "nameInputGroup";
            this.nameInputGroup.Size = new System.Drawing.Size(269, 315);
            this.nameInputGroup.TabIndex = 12;
            this.nameInputGroup.TabStop = false;
            this.nameInputGroup.Text = "Name Information";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(25, 184);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(112, 20);
            this.titleLabel.TabIndex = 13;
            this.titleLabel.Text = "Preferred Title:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(40, 140);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(90, 20);
            this.lastNameLabel.TabIndex = 13;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(32, 95);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(105, 20);
            this.middleNameLabel.TabIndex = 9;
            this.middleNameLabel.Text = "Middle Name:";
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(40, 52);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(90, 20);
            this.firstNameLabel.TabIndex = 8;
            this.firstNameLabel.Text = "First Name:";
            // 
            // titleForm
            // 
            this.titleForm.Location = new System.Drawing.Point(143, 181);
            this.titleForm.Name = "titleForm";
            this.titleForm.Size = new System.Drawing.Size(100, 26);
            this.titleForm.TabIndex = 4;
            // 
            // lastNameForm
            // 
            this.lastNameForm.Location = new System.Drawing.Point(143, 137);
            this.lastNameForm.Name = "lastNameForm";
            this.lastNameForm.Size = new System.Drawing.Size(100, 26);
            this.lastNameForm.TabIndex = 3;
            // 
            // middleNameForm
            // 
            this.middleNameForm.Location = new System.Drawing.Point(143, 92);
            this.middleNameForm.Name = "middleNameForm";
            this.middleNameForm.Size = new System.Drawing.Size(100, 26);
            this.middleNameForm.TabIndex = 2;
            // 
            // firstNameForm
            // 
            this.firstNameForm.Location = new System.Drawing.Point(143, 49);
            this.firstNameForm.Name = "firstNameForm";
            this.firstNameForm.Size = new System.Drawing.Size(100, 26);
            this.firstNameForm.TabIndex = 1;
            // 
            // nameOutputGroup
            // 
            this.nameOutputGroup.Controls.Add(this.exitButton);
            this.nameOutputGroup.Controls.Add(this.option6Label);
            this.nameOutputGroup.Controls.Add(this.option5Label);
            this.nameOutputGroup.Controls.Add(this.option4Label);
            this.nameOutputGroup.Controls.Add(this.option3Label);
            this.nameOutputGroup.Controls.Add(this.option2Label);
            this.nameOutputGroup.Controls.Add(this.option1Label);
            this.nameOutputGroup.Controls.Add(this.formattedNameLabel);
            this.nameOutputGroup.Controls.Add(this.formatOption6);
            this.nameOutputGroup.Controls.Add(this.formatOption5);
            this.nameOutputGroup.Controls.Add(this.formatOption4);
            this.nameOutputGroup.Controls.Add(this.formatOption3);
            this.nameOutputGroup.Controls.Add(this.formatOption2);
            this.nameOutputGroup.Controls.Add(this.formatOption1);
            this.nameOutputGroup.Controls.Add(this.formatNameForm);
            this.nameOutputGroup.Location = new System.Drawing.Point(316, 12);
            this.nameOutputGroup.Name = "nameOutputGroup";
            this.nameOutputGroup.Size = new System.Drawing.Size(670, 324);
            this.nameOutputGroup.TabIndex = 13;
            this.nameOutputGroup.TabStop = false;
            this.nameOutputGroup.Text = "Name Formatting";
            // 
            // option6Label
            // 
            this.option6Label.AutoSize = true;
            this.option6Label.Location = new System.Drawing.Point(79, 272);
            this.option6Label.Name = "option6Label";
            this.option6Label.Size = new System.Drawing.Size(75, 20);
            this.option6Label.TabIndex = 25;
            this.option6Label.Text = "Last/First";
            // 
            // option5Label
            // 
            this.option5Label.AutoSize = true;
            this.option5Label.Location = new System.Drawing.Point(57, 233);
            this.option5Label.Name = "option5Label";
            this.option5Label.Size = new System.Drawing.Size(125, 20);
            this.option5Label.TabIndex = 24;
            this.option5Label.Text = "Last/First/Middle";
            // 
            // option4Label
            // 
            this.option4Label.AutoSize = true;
            this.option4Label.Location = new System.Drawing.Point(44, 193);
            this.option4Label.Name = "option4Label";
            this.option4Label.Size = new System.Drawing.Size(158, 20);
            this.option4Label.TabIndex = 23;
            this.option4Label.Text = "Last/First/Middle/Title";
            // 
            // option3Label
            // 
            this.option3Label.AutoSize = true;
            this.option3Label.Location = new System.Drawing.Point(79, 156);
            this.option3Label.Name = "option3Label";
            this.option3Label.Size = new System.Drawing.Size(75, 20);
            this.option3Label.TabIndex = 22;
            this.option3Label.Text = "First/Last";
            // 
            // option2Label
            // 
            this.option2Label.AutoSize = true;
            this.option2Label.Location = new System.Drawing.Point(57, 118);
            this.option2Label.Name = "option2Label";
            this.option2Label.Size = new System.Drawing.Size(125, 20);
            this.option2Label.TabIndex = 21;
            this.option2Label.Text = "First/Middle/Last";
            // 
            // option1Label
            // 
            this.option1Label.AutoSize = true;
            this.option1Label.Location = new System.Drawing.Point(44, 78);
            this.option1Label.Name = "option1Label";
            this.option1Label.Size = new System.Drawing.Size(158, 20);
            this.option1Label.TabIndex = 20;
            this.option1Label.Text = "Title/First/Middle/Last";
            // 
            // formattedNameLabel
            // 
            this.formattedNameLabel.AutoSize = true;
            this.formattedNameLabel.Location = new System.Drawing.Point(431, 137);
            this.formattedNameLabel.Name = "formattedNameLabel";
            this.formattedNameLabel.Size = new System.Drawing.Size(133, 20);
            this.formattedNameLabel.TabIndex = 19;
            this.formattedNameLabel.Text = "Formatted Name:";
            // 
            // formatOption6
            // 
            this.formatOption6.Location = new System.Drawing.Point(231, 267);
            this.formatOption6.Name = "formatOption6";
            this.formatOption6.Size = new System.Drawing.Size(82, 31);
            this.formatOption6.TabIndex = 11;
            this.formatOption6.Text = "Option 6";
            this.formatOption6.UseVisualStyleBackColor = true;
            this.formatOption6.Click += new System.EventHandler(this.formatOption6_Click);
            // 
            // formatOption5
            // 
            this.formatOption5.Location = new System.Drawing.Point(231, 226);
            this.formatOption5.Name = "formatOption5";
            this.formatOption5.Size = new System.Drawing.Size(82, 35);
            this.formatOption5.TabIndex = 10;
            this.formatOption5.Text = "Option 5";
            this.formatOption5.UseVisualStyleBackColor = true;
            this.formatOption5.Click += new System.EventHandler(this.formatOption5_Click);
            // 
            // formatOption4
            // 
            this.formatOption4.Location = new System.Drawing.Point(231, 187);
            this.formatOption4.Name = "formatOption4";
            this.formatOption4.Size = new System.Drawing.Size(82, 33);
            this.formatOption4.TabIndex = 9;
            this.formatOption4.Text = "Option 4";
            this.formatOption4.UseVisualStyleBackColor = true;
            this.formatOption4.Click += new System.EventHandler(this.formatOption4_Click);
            // 
            // formatOption3
            // 
            this.formatOption3.Location = new System.Drawing.Point(231, 151);
            this.formatOption3.Name = "formatOption3";
            this.formatOption3.Size = new System.Drawing.Size(82, 30);
            this.formatOption3.TabIndex = 8;
            this.formatOption3.Text = "Option 3";
            this.formatOption3.UseVisualStyleBackColor = true;
            this.formatOption3.Click += new System.EventHandler(this.formatOption3_Click);
            // 
            // formatOption2
            // 
            this.formatOption2.Location = new System.Drawing.Point(231, 111);
            this.formatOption2.Name = "formatOption2";
            this.formatOption2.Size = new System.Drawing.Size(82, 34);
            this.formatOption2.TabIndex = 7;
            this.formatOption2.Text = "Option 2";
            this.formatOption2.UseVisualStyleBackColor = true;
            this.formatOption2.Click += new System.EventHandler(this.formatOption2_Click);
            // 
            // formatOption1
            // 
            this.formatOption1.Location = new System.Drawing.Point(231, 71);
            this.formatOption1.Name = "formatOption1";
            this.formatOption1.Size = new System.Drawing.Size(82, 34);
            this.formatOption1.TabIndex = 6;
            this.formatOption1.Text = "Option 1";
            this.formatOption1.UseVisualStyleBackColor = true;
            this.formatOption1.Click += new System.EventHandler(this.formatOption1_Click);
            // 
            // formatNameForm
            // 
            this.formatNameForm.Location = new System.Drawing.Point(329, 160);
            this.formatNameForm.Name = "formatNameForm";
            this.formatNameForm.Size = new System.Drawing.Size(335, 26);
            this.formatNameForm.TabIndex = 12;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(994, 369);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(577, 272);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(78, 35);
            this.exitButton.TabIndex = 26;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // nameFormatter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 375);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.nameOutputGroup);
            this.Controls.Add(this.nameInputGroup);
            this.Name = "nameFormatter";
            this.Text = "Name Formatter";
            this.nameInputGroup.ResumeLayout(false);
            this.nameInputGroup.PerformLayout();
            this.nameOutputGroup.ResumeLayout(false);
            this.nameOutputGroup.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.GroupBox nameInputGroup;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.TextBox titleForm;
        private System.Windows.Forms.TextBox lastNameForm;
        private System.Windows.Forms.TextBox middleNameForm;
        private System.Windows.Forms.TextBox firstNameForm;
        private System.Windows.Forms.GroupBox nameOutputGroup;
        private System.Windows.Forms.Label formattedNameLabel;
        private System.Windows.Forms.Button formatOption6;
        private System.Windows.Forms.Button formatOption5;
        private System.Windows.Forms.Button formatOption4;
        private System.Windows.Forms.Button formatOption3;
        private System.Windows.Forms.Button formatOption2;
        private System.Windows.Forms.Button formatOption1;
        private System.Windows.Forms.TextBox formatNameForm;
        private System.Windows.Forms.Label option6Label;
        private System.Windows.Forms.Label option5Label;
        private System.Windows.Forms.Label option4Label;
        private System.Windows.Forms.Label option3Label;
        private System.Windows.Forms.Label option2Label;
        private System.Windows.Forms.Label option1Label;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button button1;
    }
}

