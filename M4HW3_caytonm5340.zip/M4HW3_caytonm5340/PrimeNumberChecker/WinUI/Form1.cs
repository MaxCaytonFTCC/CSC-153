﻿/**
* 3/20/23
* CSC 153
* Max Cayton
* This program checks if a provided number is prime or not.
*/
using System;
using PrimeNumberLibrary;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        int inputNum;
        bool isPrime;
        public Form1()
        {
            InitializeComponent();
        }

        private void sumbitButton_Click(object sender, EventArgs e)
        {
            int.TryParse(numberTextBox.Text,out inputNum);
            isPrime = CheckPrime.IsPrime(inputNum);

            if (isPrime == true)
            {
                MessageBox.Show(inputNum.ToString() + " is a prime number.");
            }
            else
            {
                MessageBox.Show(inputNum.ToString() + " is not a prime number.");
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
