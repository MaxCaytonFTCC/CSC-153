﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimeNumberLibrary
{
    public class CheckPrime
    {
        public static bool IsPrime(int inputNum)
        {
            for (int i = 9; i > 2; i--)
            {
                if (inputNum <= 1)
                {
                    return false;
                }
                else if (i != inputNum && i != 1)
                {
                    if (inputNum % i == 0)
                    {
                        return false;
                    }
                }
            }
            return true;
        }
    }
}
