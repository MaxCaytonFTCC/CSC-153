﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaLibrary
{
    public class Area
    {
        // Default Constructor
        public Area()
        {

        }

        // Overloaded Methods

        // Circle
        public static double CalculateArea(double radius)
        {
            return (Math.PI * (radius * radius));
        }

        // Rectangle
        public static double CalculateArea(double width, double length)
        {
            return (width * length);
        }

        // Cylinder       
        public static double CalculateArea(string radius, string height)
        {
            double radiusParsed = double.Parse(radius);
            double heightParsed = double.Parse(height);
            return (Math.PI * (radiusParsed * radiusParsed) * heightParsed);
        }
    }
}