﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AreaLibrary
{
    public static class AppControl
    {
        public static bool ValidateTextBox(string textInput)
        {
            double result;

            if (double.TryParse(textInput, out result))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

    }
}
