﻿/**
* 4/27/23
* CSC 153
* Max Cayton
* This program calculates the area of a selected shape.
*/
using System;
using AreaLibrary;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
           
           // Validate Input
           bool firstInputValid = AppControl.ValidateTextBox(firstInputTextBox.Text);
           bool secondInputValid = AppControl.ValidateTextBox(secondInputTextBox.Text);

            // Use Overloaded Method to Perform Correct Calculation
            if (circleRadioButton.Checked && firstInputValid == true)
            {                
                MessageBox.Show("Area = " + Area.CalculateArea(double.Parse(firstInputTextBox.Text)).ToString());
            }

            else if (rectangleRadioButton.Checked && firstInputValid == true && secondInputValid == true)
            {
                MessageBox.Show("Area = "+ Area.CalculateArea(double.Parse(firstInputTextBox.Text), double.Parse(secondInputTextBox.Text)).ToString());
            }

            else if (cylinderRadioButton.Checked && firstInputValid == true && secondInputValid == true)
            {
                MessageBox.Show("Area = " + Area.CalculateArea(firstInputTextBox.Text, secondInputTextBox.Text).ToString());
            }
            
        }

        private void circleRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            // Adjust Labels
            firstInputLabel.Visible = true;
            firstInputLabel.Text = "Enter Radius:";

            secondInputLabel.Visible = false;
            secondInputLabel.Text = "";

            // Adjust Input Boxes
            firstInputTextBox.Visible = true;
            firstInputTextBox.Text = "";

            secondInputTextBox.Visible = false;
            secondInputTextBox.Text = "";
        }

        private void rectangleRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            // Adjust Labels
            firstInputLabel.Visible = true;
            firstInputLabel.Text = "Enter Width:";

            secondInputLabel.Visible = true;
            secondInputLabel.Text = "Enter Length";

            // Adjust Input Boxes
            firstInputTextBox.Visible = true;
            firstInputTextBox.Text = "";

            secondInputTextBox.Visible = true;
            secondInputTextBox.Text = "";
        }

        private void cylinderRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            // Adjust Labels
            firstInputLabel.Visible = true;
            firstInputLabel.Text = "Enter Radius:";

            secondInputLabel.Visible = true;
            secondInputLabel.Text = "Enter Height";

            // Adjust Input Boxes
            firstInputTextBox.Visible = true;
            firstInputTextBox.Text = "";

            secondInputTextBox.Visible = true;
            secondInputTextBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
