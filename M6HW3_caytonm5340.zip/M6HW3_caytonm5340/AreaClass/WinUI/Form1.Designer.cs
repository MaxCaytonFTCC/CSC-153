﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstInputTextBox = new System.Windows.Forms.TextBox();
            this.secondInputTextBox = new System.Windows.Forms.TextBox();
            this.selectionGroupBox = new System.Windows.Forms.GroupBox();
            this.cylinderRadioButton = new System.Windows.Forms.RadioButton();
            this.rectangleRadioButton = new System.Windows.Forms.RadioButton();
            this.circleRadioButton = new System.Windows.Forms.RadioButton();
            this.firstInputLabel = new System.Windows.Forms.Label();
            this.secondInputLabel = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.selectionGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // firstInputTextBox
            // 
            this.firstInputTextBox.Location = new System.Drawing.Point(310, 45);
            this.firstInputTextBox.Name = "firstInputTextBox";
            this.firstInputTextBox.Size = new System.Drawing.Size(100, 26);
            this.firstInputTextBox.TabIndex = 0;
            this.firstInputTextBox.Visible = false;
            // 
            // secondInputTextBox
            // 
            this.secondInputTextBox.Location = new System.Drawing.Point(310, 92);
            this.secondInputTextBox.Name = "secondInputTextBox";
            this.secondInputTextBox.Size = new System.Drawing.Size(100, 26);
            this.secondInputTextBox.TabIndex = 1;
            this.secondInputTextBox.Visible = false;
            // 
            // selectionGroupBox
            // 
            this.selectionGroupBox.Controls.Add(this.cylinderRadioButton);
            this.selectionGroupBox.Controls.Add(this.rectangleRadioButton);
            this.selectionGroupBox.Controls.Add(this.circleRadioButton);
            this.selectionGroupBox.Location = new System.Drawing.Point(29, 31);
            this.selectionGroupBox.Name = "selectionGroupBox";
            this.selectionGroupBox.Size = new System.Drawing.Size(141, 161);
            this.selectionGroupBox.TabIndex = 3;
            this.selectionGroupBox.TabStop = false;
            this.selectionGroupBox.Text = "Select a Shape";
            // 
            // cylinderRadioButton
            // 
            this.cylinderRadioButton.AutoSize = true;
            this.cylinderRadioButton.Location = new System.Drawing.Point(19, 104);
            this.cylinderRadioButton.Name = "cylinderRadioButton";
            this.cylinderRadioButton.Size = new System.Drawing.Size(90, 24);
            this.cylinderRadioButton.TabIndex = 2;
            this.cylinderRadioButton.TabStop = true;
            this.cylinderRadioButton.Text = "Cylinder";
            this.cylinderRadioButton.UseVisualStyleBackColor = true;
            this.cylinderRadioButton.CheckedChanged += new System.EventHandler(this.cylinderRadioButton_CheckedChanged);
            // 
            // rectangleRadioButton
            // 
            this.rectangleRadioButton.AutoSize = true;
            this.rectangleRadioButton.Location = new System.Drawing.Point(19, 73);
            this.rectangleRadioButton.Name = "rectangleRadioButton";
            this.rectangleRadioButton.Size = new System.Drawing.Size(107, 24);
            this.rectangleRadioButton.TabIndex = 1;
            this.rectangleRadioButton.TabStop = true;
            this.rectangleRadioButton.Text = "Rectangle";
            this.rectangleRadioButton.UseVisualStyleBackColor = true;
            this.rectangleRadioButton.CheckedChanged += new System.EventHandler(this.rectangleRadioButton_CheckedChanged);
            // 
            // circleRadioButton
            // 
            this.circleRadioButton.AutoSize = true;
            this.circleRadioButton.Location = new System.Drawing.Point(19, 40);
            this.circleRadioButton.Name = "circleRadioButton";
            this.circleRadioButton.Size = new System.Drawing.Size(73, 24);
            this.circleRadioButton.TabIndex = 0;
            this.circleRadioButton.TabStop = true;
            this.circleRadioButton.Text = "Circle";
            this.circleRadioButton.UseVisualStyleBackColor = true;
            this.circleRadioButton.CheckedChanged += new System.EventHandler(this.circleRadioButton_CheckedChanged);
            // 
            // firstInputLabel
            // 
            this.firstInputLabel.AutoSize = true;
            this.firstInputLabel.Location = new System.Drawing.Point(198, 48);
            this.firstInputLabel.Name = "firstInputLabel";
            this.firstInputLabel.Size = new System.Drawing.Size(33, 20);
            this.firstInputLabel.TabIndex = 4;
            this.firstInputLabel.Text = "null";
            this.firstInputLabel.Visible = false;
            // 
            // secondInputLabel
            // 
            this.secondInputLabel.AutoSize = true;
            this.secondInputLabel.Location = new System.Drawing.Point(198, 95);
            this.secondInputLabel.Name = "secondInputLabel";
            this.secondInputLabel.Size = new System.Drawing.Size(33, 20);
            this.secondInputLabel.TabIndex = 5;
            this.secondInputLabel.Text = "null";
            this.secondInputLabel.Visible = false;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(230, 157);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(79, 35);
            this.submitButton.TabIndex = 7;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(336, 157);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(72, 35);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 240);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.secondInputLabel);
            this.Controls.Add(this.firstInputLabel);
            this.Controls.Add(this.selectionGroupBox);
            this.Controls.Add(this.secondInputTextBox);
            this.Controls.Add(this.firstInputTextBox);
            this.Name = "Form1";
            this.Text = "Area Calculator";
            this.selectionGroupBox.ResumeLayout(false);
            this.selectionGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox firstInputTextBox;
        private System.Windows.Forms.TextBox secondInputTextBox;
        private System.Windows.Forms.GroupBox selectionGroupBox;
        private System.Windows.Forms.RadioButton cylinderRadioButton;
        private System.Windows.Forms.RadioButton rectangleRadioButton;
        private System.Windows.Forms.RadioButton circleRadioButton;
        private System.Windows.Forms.Label firstInputLabel;
        private System.Windows.Forms.Label secondInputLabel;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Button exitButton;
    }
}

