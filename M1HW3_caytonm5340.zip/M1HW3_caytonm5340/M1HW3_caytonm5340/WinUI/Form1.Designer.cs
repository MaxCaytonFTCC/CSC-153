﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.propertyValueTextBox = new System.Windows.Forms.TextBox();
            this.propertyValueLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.propertyTaxLabel = new System.Windows.Forms.Label();
            this.propertyTaxTextBox = new System.Windows.Forms.TextBox();
            this.inputGroupBox = new System.Windows.Forms.GroupBox();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.inputGroupBox.SuspendLayout();
            this.outputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // propertyValueTextBox
            // 
            this.propertyValueTextBox.Location = new System.Drawing.Point(287, 45);
            this.propertyValueTextBox.Name = "propertyValueTextBox";
            this.propertyValueTextBox.Size = new System.Drawing.Size(100, 26);
            this.propertyValueTextBox.TabIndex = 0;
            // 
            // propertyValueLabel
            // 
            this.propertyValueLabel.AutoSize = true;
            this.propertyValueLabel.Location = new System.Drawing.Point(36, 48);
            this.propertyValueLabel.Name = "propertyValueLabel";
            this.propertyValueLabel.Size = new System.Drawing.Size(245, 20);
            this.propertyValueLabel.TabIndex = 1;
            this.propertyValueLabel.Text = "Input The Value of Your Property:";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(287, 96);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(100, 36);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // propertyTaxLabel
            // 
            this.propertyTaxLabel.AutoSize = true;
            this.propertyTaxLabel.Location = new System.Drawing.Point(36, 48);
            this.propertyTaxLabel.Name = "propertyTaxLabel";
            this.propertyTaxLabel.Size = new System.Drawing.Size(210, 20);
            this.propertyTaxLabel.TabIndex = 3;
            this.propertyTaxLabel.Text = "Your Property Tax This Year:";
            // 
            // propertyTaxTextBox
            // 
            this.propertyTaxTextBox.Location = new System.Drawing.Point(287, 42);
            this.propertyTaxTextBox.Name = "propertyTaxTextBox";
            this.propertyTaxTextBox.Size = new System.Drawing.Size(100, 26);
            this.propertyTaxTextBox.TabIndex = 4;
            // 
            // inputGroupBox
            // 
            this.inputGroupBox.Controls.Add(this.calculateButton);
            this.inputGroupBox.Controls.Add(this.propertyValueTextBox);
            this.inputGroupBox.Controls.Add(this.propertyValueLabel);
            this.inputGroupBox.Location = new System.Drawing.Point(61, 25);
            this.inputGroupBox.Name = "inputGroupBox";
            this.inputGroupBox.Size = new System.Drawing.Size(448, 166);
            this.inputGroupBox.TabIndex = 5;
            this.inputGroupBox.TabStop = false;
            this.inputGroupBox.Text = "Input";
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.propertyTaxTextBox);
            this.outputGroupBox.Controls.Add(this.propertyTaxLabel);
            this.outputGroupBox.Location = new System.Drawing.Point(61, 264);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(448, 102);
            this.outputGroupBox.TabIndex = 6;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Output";
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(348, 392);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 38);
            this.clearButton.TabIndex = 7;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(434, 392);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 38);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 442);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.inputGroupBox);
            this.Name = "Form1";
            this.Text = "Property Tax Calculator";
            this.inputGroupBox.ResumeLayout(false);
            this.inputGroupBox.PerformLayout();
            this.outputGroupBox.ResumeLayout(false);
            this.outputGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox propertyValueTextBox;
        private System.Windows.Forms.Label propertyValueLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Label propertyTaxLabel;
        private System.Windows.Forms.TextBox propertyTaxTextBox;
        private System.Windows.Forms.GroupBox inputGroupBox;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

