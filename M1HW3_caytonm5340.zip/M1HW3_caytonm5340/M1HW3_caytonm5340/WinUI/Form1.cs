﻿/**
* 1/30/2023
* CSC 153
* Max Cayton
* This program takes the value of the user's property as input and calculates its yearly property tax.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {

        const decimal CENTS = 0.64m;
        const int DOLLARS = 100;

        decimal propertyValue, propertyTax;

        public Form1()
        {
            InitializeComponent();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear TextBoxes
            propertyValueTextBox.Clear();
            propertyTaxTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {

            // Gather the property's value from the user
            propertyValue = decimal.Parse(propertyValueTextBox.Text);

            // Clear the textbox to communicate that the input was collected
            propertyValueTextBox.Clear();

            // Calculate Property Tax
            propertyTax = (propertyValue / DOLLARS) * CENTS;

            // Display it
            propertyTaxTextBox.Text = propertyTax.ToString("c");

        }
    }
}
