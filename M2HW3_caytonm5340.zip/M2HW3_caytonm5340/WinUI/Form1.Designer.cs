﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputGroupBox = new System.Windows.Forms.GroupBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.inputSecondsTextBox = new System.Windows.Forms.TextBox();
            this.inputSecondsLabel = new System.Windows.Forms.Label();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.daysTextBox = new System.Windows.Forms.TextBox();
            this.hoursTextBox = new System.Windows.Forms.TextBox();
            this.minutesTextBox = new System.Windows.Forms.TextBox();
            this.secondsTextBox = new System.Windows.Forms.TextBox();
            this.secondsLabel = new System.Windows.Forms.Label();
            this.minutesLabel = new System.Windows.Forms.Label();
            this.hoursLabel = new System.Windows.Forms.Label();
            this.daysLabel = new System.Windows.Forms.Label();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.inputGroupBox.SuspendLayout();
            this.outputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // inputGroupBox
            // 
            this.inputGroupBox.Controls.Add(this.inputSecondsLabel);
            this.inputGroupBox.Controls.Add(this.inputSecondsTextBox);
            this.inputGroupBox.Controls.Add(this.submitButton);
            this.inputGroupBox.Location = new System.Drawing.Point(31, 42);
            this.inputGroupBox.Name = "inputGroupBox";
            this.inputGroupBox.Size = new System.Drawing.Size(342, 152);
            this.inputGroupBox.TabIndex = 0;
            this.inputGroupBox.TabStop = false;
            this.inputGroupBox.Text = "Input";
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(209, 97);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(100, 40);
            this.submitButton.TabIndex = 1;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // inputSecondsTextBox
            // 
            this.inputSecondsTextBox.Location = new System.Drawing.Point(209, 39);
            this.inputSecondsTextBox.Name = "inputSecondsTextBox";
            this.inputSecondsTextBox.Size = new System.Drawing.Size(100, 26);
            this.inputSecondsTextBox.TabIndex = 0;
            // 
            // inputSecondsLabel
            // 
            this.inputSecondsLabel.AutoSize = true;
            this.inputSecondsLabel.Location = new System.Drawing.Point(6, 39);
            this.inputSecondsLabel.Name = "inputSecondsLabel";
            this.inputSecondsLabel.Size = new System.Drawing.Size(197, 20);
            this.inputSecondsLabel.TabIndex = 2;
            this.inputSecondsLabel.Text = "Enter Number of Seconds:";
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.resetButton);
            this.outputGroupBox.Controls.Add(this.daysLabel);
            this.outputGroupBox.Controls.Add(this.hoursLabel);
            this.outputGroupBox.Controls.Add(this.minutesLabel);
            this.outputGroupBox.Controls.Add(this.secondsLabel);
            this.outputGroupBox.Controls.Add(this.secondsTextBox);
            this.outputGroupBox.Controls.Add(this.minutesTextBox);
            this.outputGroupBox.Controls.Add(this.hoursTextBox);
            this.outputGroupBox.Controls.Add(this.daysTextBox);
            this.outputGroupBox.Location = new System.Drawing.Point(399, 42);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(338, 152);
            this.outputGroupBox.TabIndex = 1;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Output";
            // 
            // daysTextBox
            // 
            this.daysTextBox.Location = new System.Drawing.Point(152, 19);
            this.daysTextBox.Name = "daysTextBox";
            this.daysTextBox.Size = new System.Drawing.Size(100, 26);
            this.daysTextBox.TabIndex = 2;
            // 
            // hoursTextBox
            // 
            this.hoursTextBox.Location = new System.Drawing.Point(152, 51);
            this.hoursTextBox.Name = "hoursTextBox";
            this.hoursTextBox.Size = new System.Drawing.Size(100, 26);
            this.hoursTextBox.TabIndex = 3;
            // 
            // minutesTextBox
            // 
            this.minutesTextBox.Location = new System.Drawing.Point(152, 83);
            this.minutesTextBox.Name = "minutesTextBox";
            this.minutesTextBox.Size = new System.Drawing.Size(100, 26);
            this.minutesTextBox.TabIndex = 4;
            // 
            // secondsTextBox
            // 
            this.secondsTextBox.Location = new System.Drawing.Point(152, 115);
            this.secondsTextBox.Name = "secondsTextBox";
            this.secondsTextBox.Size = new System.Drawing.Size(100, 26);
            this.secondsTextBox.TabIndex = 5;
            // 
            // secondsLabel
            // 
            this.secondsLabel.AutoSize = true;
            this.secondsLabel.Location = new System.Drawing.Point(258, 117);
            this.secondsLabel.Name = "secondsLabel";
            this.secondsLabel.Size = new System.Drawing.Size(72, 20);
            this.secondsLabel.TabIndex = 4;
            this.secondsLabel.Text = "Seconds";
            // 
            // minutesLabel
            // 
            this.minutesLabel.AutoSize = true;
            this.minutesLabel.Location = new System.Drawing.Point(258, 86);
            this.minutesLabel.Name = "minutesLabel";
            this.minutesLabel.Size = new System.Drawing.Size(65, 20);
            this.minutesLabel.TabIndex = 5;
            this.minutesLabel.Text = "Minutes";
            // 
            // hoursLabel
            // 
            this.hoursLabel.AutoSize = true;
            this.hoursLabel.Location = new System.Drawing.Point(258, 54);
            this.hoursLabel.Name = "hoursLabel";
            this.hoursLabel.Size = new System.Drawing.Size(52, 20);
            this.hoursLabel.TabIndex = 6;
            this.hoursLabel.Text = "Hours";
            // 
            // daysLabel
            // 
            this.daysLabel.AutoSize = true;
            this.daysLabel.Location = new System.Drawing.Point(258, 19);
            this.daysLabel.Name = "daysLabel";
            this.daysLabel.Size = new System.Drawing.Size(45, 20);
            this.daysLabel.TabIndex = 7;
            this.daysLabel.Text = "Days";
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(25, 97);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(100, 40);
            this.resetButton.TabIndex = 6;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(662, 210);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 33);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(772, 255);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.inputGroupBox);
            this.Name = "Form1";
            this.Text = "Time Calculator";
            this.inputGroupBox.ResumeLayout(false);
            this.inputGroupBox.PerformLayout();
            this.outputGroupBox.ResumeLayout(false);
            this.outputGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox inputGroupBox;
        private System.Windows.Forms.Label inputSecondsLabel;
        private System.Windows.Forms.TextBox inputSecondsTextBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Label daysLabel;
        private System.Windows.Forms.Label hoursLabel;
        private System.Windows.Forms.Label minutesLabel;
        private System.Windows.Forms.Label secondsLabel;
        private System.Windows.Forms.TextBox secondsTextBox;
        private System.Windows.Forms.TextBox minutesTextBox;
        private System.Windows.Forms.TextBox hoursTextBox;
        private System.Windows.Forms.TextBox daysTextBox;
        private System.Windows.Forms.Button exitButton;
    }
}

