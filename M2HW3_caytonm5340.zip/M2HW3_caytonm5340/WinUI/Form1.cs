﻿/**
* 2/14/23
* CSC 153
* Max Cayton
* This program takes a number of seconds as input and calculates the number of days, hours, minutes and leftover seconds.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        int secondsCount = 0, minutesCount = 0, hoursCount = 0, daysCount = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            // Gather Input
            int.TryParse(inputSecondsTextBox.Text, out secondsCount);

            // Divide given seconds into other units
            if (secondsCount >= 86400)
            {
                daysCount = (secondsCount / 86400);
                secondsCount -= 86400 * daysCount;
            }
            else
            {
                daysCount = 0;
            }

            if (secondsCount >= 3600) 
            {
                hoursCount = (secondsCount / 3600);
                secondsCount -= 3600 * hoursCount;
            }
            else
            {
                hoursCount = 0;
            }

            if (secondsCount >= 60)
            {
                minutesCount = (secondsCount / 60);
                secondsCount -= 60 * minutesCount;
            }
            else
            {
                minutesCount = 0;
            }

            inputSecondsTextBox.Clear();

            daysTextBox.Text = daysCount.ToString();
            hoursTextBox.Text = hoursCount.ToString();
            minutesTextBox.Text = minutesCount.ToString();
            secondsTextBox.Text = secondsCount.ToString();

        }

        private void resetButton_Click(object sender, EventArgs e)
        {
            inputSecondsTextBox.Clear();
            daysTextBox.Clear();
            hoursTextBox.Clear();
            minutesTextBox.Clear();
            secondsTextBox.Clear();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
