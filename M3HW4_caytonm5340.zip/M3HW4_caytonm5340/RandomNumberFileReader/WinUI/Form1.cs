﻿/**
* 3/6/23
* CSC 153
* Max Cayton
* This program opens a file filled with random numbers, calculates their sum and how many there are, and displays its contents.
*/
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        int numTotal = 0;
        int numberCount = 0;
        string num;
        StreamReader inputFile;

        public Form1()
        {
            InitializeComponent();
        }

        private void openButton_Click(object sender, EventArgs e)
        {
            // Clears any previous data
            numbersListBox.Items.Clear();

            // Gets the file from the user and calculates the total, the number of numbers, and adds them to the list box
            try
            {
                if (numberOpenFileDialog.ShowDialog() == DialogResult.OK)
                {
                    inputFile = File.OpenText(numberOpenFileDialog.FileName);

                    while (!inputFile.EndOfStream)
                    {
                        num = inputFile.ReadLine();
                        numbersListBox.Items.Add(num);
                        numTotal += int.Parse(num);
                        numberCount++;
                    }

                    inputFile.Close();

                    MessageBox.Show("Total: "+numTotal.ToString()+" Number of Random Numbers: "+numberCount);

                    // Reset Variables
                    numTotal = 0;
                    numberCount = 0;

                }

            }

            // Prevents any file handling errors from crashing the program
            catch
            {
                MessageBox.Show("Something went wrong, try again.");
            }
            
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}