﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputBox = new System.Windows.Forms.GroupBox();
            this.paintCostPerGalLabel = new System.Windows.Forms.Label();
            this.squareFeetLabel = new System.Windows.Forms.Label();
            this.enterButton = new System.Windows.Forms.Button();
            this.paintCostPerGalTextBox = new System.Windows.Forms.TextBox();
            this.squareFeetTextBox = new System.Windows.Forms.TextBox();
            this.outputBox = new System.Windows.Forms.GroupBox();
            this.totalCostTextBox = new System.Windows.Forms.TextBox();
            this.laborCostTextBox = new System.Windows.Forms.TextBox();
            this.paintCostTextBox = new System.Windows.Forms.TextBox();
            this.laborHoursTextBox = new System.Windows.Forms.TextBox();
            this.gallonCountTextBox = new System.Windows.Forms.TextBox();
            this.totalCostLabel = new System.Windows.Forms.Label();
            this.laborCostLabel = new System.Windows.Forms.Label();
            this.paintCostLabel = new System.Windows.Forms.Label();
            this.hoursRequiredLabel = new System.Windows.Forms.Label();
            this.paintRequiredLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.inputBox.SuspendLayout();
            this.outputBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // inputBox
            // 
            this.inputBox.Controls.Add(this.clearButton);
            this.inputBox.Controls.Add(this.paintCostPerGalLabel);
            this.inputBox.Controls.Add(this.squareFeetLabel);
            this.inputBox.Controls.Add(this.enterButton);
            this.inputBox.Controls.Add(this.paintCostPerGalTextBox);
            this.inputBox.Controls.Add(this.squareFeetTextBox);
            this.inputBox.Location = new System.Drawing.Point(90, 53);
            this.inputBox.Name = "inputBox";
            this.inputBox.Size = new System.Drawing.Size(419, 279);
            this.inputBox.TabIndex = 0;
            this.inputBox.TabStop = false;
            this.inputBox.Text = "Input";
            // 
            // paintCostPerGalLabel
            // 
            this.paintCostPerGalLabel.AutoSize = true;
            this.paintCostPerGalLabel.Location = new System.Drawing.Point(32, 85);
            this.paintCostPerGalLabel.Name = "paintCostPerGalLabel";
            this.paintCostPerGalLabel.Size = new System.Drawing.Size(247, 20);
            this.paintCostPerGalLabel.TabIndex = 4;
            this.paintCostPerGalLabel.Text = "Enter the price of paint per gallon:";
            // 
            // squareFeetLabel
            // 
            this.squareFeetLabel.AutoSize = true;
            this.squareFeetLabel.Location = new System.Drawing.Point(32, 43);
            this.squareFeetLabel.Name = "squareFeetLabel";
            this.squareFeetLabel.Size = new System.Drawing.Size(232, 20);
            this.squareFeetLabel.TabIndex = 3;
            this.squareFeetLabel.Text = "Enter square feet of wall space:";
            // 
            // enterButton
            // 
            this.enterButton.Location = new System.Drawing.Point(309, 144);
            this.enterButton.Name = "enterButton";
            this.enterButton.Size = new System.Drawing.Size(78, 39);
            this.enterButton.TabIndex = 2;
            this.enterButton.Text = "Enter";
            this.enterButton.UseVisualStyleBackColor = true;
            this.enterButton.Click += new System.EventHandler(this.enterButton_Click);
            // 
            // paintCostPerGalTextBox
            // 
            this.paintCostPerGalTextBox.Location = new System.Drawing.Point(287, 85);
            this.paintCostPerGalTextBox.Name = "paintCostPerGalTextBox";
            this.paintCostPerGalTextBox.Size = new System.Drawing.Size(100, 26);
            this.paintCostPerGalTextBox.TabIndex = 1;
            // 
            // squareFeetTextBox
            // 
            this.squareFeetTextBox.Location = new System.Drawing.Point(287, 43);
            this.squareFeetTextBox.Name = "squareFeetTextBox";
            this.squareFeetTextBox.Size = new System.Drawing.Size(100, 26);
            this.squareFeetTextBox.TabIndex = 0;
            // 
            // outputBox
            // 
            this.outputBox.Controls.Add(this.totalCostTextBox);
            this.outputBox.Controls.Add(this.laborCostTextBox);
            this.outputBox.Controls.Add(this.paintCostTextBox);
            this.outputBox.Controls.Add(this.laborHoursTextBox);
            this.outputBox.Controls.Add(this.gallonCountTextBox);
            this.outputBox.Controls.Add(this.totalCostLabel);
            this.outputBox.Controls.Add(this.laborCostLabel);
            this.outputBox.Controls.Add(this.paintCostLabel);
            this.outputBox.Controls.Add(this.hoursRequiredLabel);
            this.outputBox.Controls.Add(this.paintRequiredLabel);
            this.outputBox.Location = new System.Drawing.Point(90, 529);
            this.outputBox.Name = "outputBox";
            this.outputBox.Size = new System.Drawing.Size(419, 256);
            this.outputBox.TabIndex = 1;
            this.outputBox.TabStop = false;
            this.outputBox.Text = "Output";
            // 
            // totalCostTextBox
            // 
            this.totalCostTextBox.Location = new System.Drawing.Point(266, 199);
            this.totalCostTextBox.Name = "totalCostTextBox";
            this.totalCostTextBox.Size = new System.Drawing.Size(100, 26);
            this.totalCostTextBox.TabIndex = 8;
            // 
            // laborCostTextBox
            // 
            this.laborCostTextBox.Location = new System.Drawing.Point(266, 158);
            this.laborCostTextBox.Name = "laborCostTextBox";
            this.laborCostTextBox.Size = new System.Drawing.Size(100, 26);
            this.laborCostTextBox.TabIndex = 7;
            // 
            // paintCostTextBox
            // 
            this.paintCostTextBox.Location = new System.Drawing.Point(266, 121);
            this.paintCostTextBox.Name = "paintCostTextBox";
            this.paintCostTextBox.Size = new System.Drawing.Size(100, 26);
            this.paintCostTextBox.TabIndex = 6;
            // 
            // laborHoursTextBox
            // 
            this.laborHoursTextBox.Location = new System.Drawing.Point(266, 86);
            this.laborHoursTextBox.Name = "laborHoursTextBox";
            this.laborHoursTextBox.Size = new System.Drawing.Size(100, 26);
            this.laborHoursTextBox.TabIndex = 5;
            // 
            // gallonCountTextBox
            // 
            this.gallonCountTextBox.Location = new System.Drawing.Point(266, 52);
            this.gallonCountTextBox.Name = "gallonCountTextBox";
            this.gallonCountTextBox.Size = new System.Drawing.Size(100, 26);
            this.gallonCountTextBox.TabIndex = 4;
            // 
            // totalCostLabel
            // 
            this.totalCostLabel.AutoSize = true;
            this.totalCostLabel.Location = new System.Drawing.Point(32, 202);
            this.totalCostLabel.Name = "totalCostLabel";
            this.totalCostLabel.Size = new System.Drawing.Size(82, 20);
            this.totalCostLabel.TabIndex = 4;
            this.totalCostLabel.Text = "Total cost:";
            // 
            // laborCostLabel
            // 
            this.laborCostLabel.AutoSize = true;
            this.laborCostLabel.Location = new System.Drawing.Point(32, 161);
            this.laborCostLabel.Name = "laborCostLabel";
            this.laborCostLabel.Size = new System.Drawing.Size(88, 20);
            this.laborCostLabel.TabIndex = 3;
            this.laborCostLabel.Text = "Labor cost:";
            // 
            // paintCostLabel
            // 
            this.paintCostLabel.AutoSize = true;
            this.paintCostLabel.Location = new System.Drawing.Point(32, 124);
            this.paintCostLabel.Name = "paintCostLabel";
            this.paintCostLabel.Size = new System.Drawing.Size(83, 20);
            this.paintCostLabel.TabIndex = 2;
            this.paintCostLabel.Text = "Paint cost:";
            // 
            // hoursRequiredLabel
            // 
            this.hoursRequiredLabel.AutoSize = true;
            this.hoursRequiredLabel.Location = new System.Drawing.Point(32, 86);
            this.hoursRequiredLabel.Name = "hoursRequiredLabel";
            this.hoursRequiredLabel.Size = new System.Drawing.Size(175, 20);
            this.hoursRequiredLabel.TabIndex = 1;
            this.hoursRequiredLabel.Text = "Hours of labor required:";
            // 
            // paintRequiredLabel
            // 
            this.paintRequiredLabel.AutoSize = true;
            this.paintRequiredLabel.Location = new System.Drawing.Point(32, 52);
            this.paintRequiredLabel.Name = "paintRequiredLabel";
            this.paintRequiredLabel.Size = new System.Drawing.Size(183, 20);
            this.paintRequiredLabel.TabIndex = 0;
            this.paintRequiredLabel.Text = "Gallons of paint requred:";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(434, 910);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 32);
            this.exitButton.TabIndex = 10;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(312, 216);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 35);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 983);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.outputBox);
            this.Controls.Add(this.inputBox);
            this.Name = "Form1";
            this.Text = "Paint Job Estimator";
            this.inputBox.ResumeLayout(false);
            this.inputBox.PerformLayout();
            this.outputBox.ResumeLayout(false);
            this.outputBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox inputBox;
        private System.Windows.Forms.Label squareFeetLabel;
        private System.Windows.Forms.Button enterButton;
        private System.Windows.Forms.TextBox paintCostPerGalTextBox;
        private System.Windows.Forms.TextBox squareFeetTextBox;
        private System.Windows.Forms.Label paintCostPerGalLabel;
        private System.Windows.Forms.GroupBox outputBox;
        private System.Windows.Forms.TextBox totalCostTextBox;
        private System.Windows.Forms.TextBox laborCostTextBox;
        private System.Windows.Forms.TextBox paintCostTextBox;
        private System.Windows.Forms.TextBox laborHoursTextBox;
        private System.Windows.Forms.TextBox gallonCountTextBox;
        private System.Windows.Forms.Label totalCostLabel;
        private System.Windows.Forms.Label laborCostLabel;
        private System.Windows.Forms.Label paintCostLabel;
        private System.Windows.Forms.Label hoursRequiredLabel;
        private System.Windows.Forms.Label paintRequiredLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

