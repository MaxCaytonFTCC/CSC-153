﻿/**
* 1/24/2023
* CSC 153
* Max Cayton
* This program estimates the cost and resources required for a paint job based on the square feet of the wall and paint cost per gallon given as input.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        private const int WALL_SPACE = 115;
        private const decimal LABOR_RATE = 20.00m;
        private const int HOURS = 8;

        private int squareFeet;

        private decimal paintCostPerGal, gallonCount, laborHours, paintCost, laborCost, totalCost;

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear All Textboxes
            squareFeetTextBox.Clear();
            paintCostPerGalTextBox.Clear();
            gallonCountTextBox.Clear();
            laborHoursTextBox.Clear();
            paintCostTextBox.Clear();
            laborCostTextBox.Clear();
            totalCostTextBox.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            // Collect the Input from the Textboxes
            squareFeet = int.Parse(squareFeetTextBox.Text);
            paintCostPerGal = decimal.Parse(paintCostPerGalTextBox.Text);

            // Calculations
            gallonCount = squareFeet / WALL_SPACE;
            laborHours = squareFeet / WALL_SPACE * HOURS;
            paintCost = paintCostPerGal * gallonCount;
            laborCost = laborHours * LABOR_RATE;
            totalCost = paintCost + laborCost;

            // Apply Calculations to Output Textboxes
            gallonCountTextBox.Text = gallonCount.ToString();
            laborHoursTextBox.Text = laborHours.ToString();
            paintCostTextBox.Text = paintCost.ToString("c");
            laborCostTextBox.Text = laborCost.ToString("c");
            totalCostTextBox.Text = totalCost.ToString("c");

        }
    }
}
