﻿/**
* 4/24/23
* CSC 153
* Max Cayton
* This program displays employee information.
*/
using System;
using EmployeeLibrary;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Create Employee Objects
            Employee susan = new Employee("Susan Meyers", 47899, "Accounting", "Vice President");
            Employee mark = new Employee("Mark Jones", 39119, "IT", "Programmer");
            Employee joy = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");

            // Display Employee Information
            employeeDataGridView.Rows.Add(susan.Name, susan.IDNumber.ToString(), susan.Department, susan.Position);
            employeeDataGridView.Rows.Add(mark.Name, mark.IDNumber.ToString(), mark.Department, mark.Position);
            employeeDataGridView.Rows.Add(joy.Name, joy.IDNumber.ToString(), joy.Department, joy.Position);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}