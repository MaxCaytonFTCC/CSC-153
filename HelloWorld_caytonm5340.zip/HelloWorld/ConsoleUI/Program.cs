﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("My name is Max Cayton");
            Console.WriteLine("I hope to learn Object Oriented Programming concepts for use in Game Development.");
            Console.WriteLine("I have taken CIS-115 and CTI-110");
            Console.WriteLine("Classes were not covered.");
            Console.ReadLine();
        }
    }
}
