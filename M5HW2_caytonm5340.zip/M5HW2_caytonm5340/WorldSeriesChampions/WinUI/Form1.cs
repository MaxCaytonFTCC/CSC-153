﻿/**
* 4/5/2023
* CSC 153
* Max Cayton
* This program displays how many times a selected team has won the World Series from 1903 through 2012.
*/
using System;
using System.IO;
using WorldSeries;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            // Pass the selection
            if (teamListBox.SelectedIndex != -1)
            {
                MessageBox.Show("The team "+teamListBox.SelectedItem.ToString()
                +" has won the World Series "+Teams.GetWins(teamListBox.SelectedItem.ToString())+" time(s) from 1903 through 2012.");
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Read the File            
            StreamReader inputFile;

            inputFile = File.OpenText("Teams.txt");

            while (!inputFile.EndOfStream)
            {
                teamListBox.Items.Add(inputFile.ReadLine());
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}