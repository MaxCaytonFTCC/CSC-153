﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorldSeries
{
    public class Teams
    {
        public static int GetWins(string selectedTeam)
        {

            List<string> winners = new List<string>();
            int winCount = 0;

            // Read the File            
            StreamReader inputFile;

            inputFile = File.OpenText("WorldSeriesWinners.txt");
            
            while (!inputFile.EndOfStream)
            {
                winners.Add(inputFile.ReadLine());
            }

            // Count the Winners
            foreach (string win in winners)
            {
                if (win.Equals(selectedTeam))
                {
                    winCount++;
                }
            }
            
            return winCount;

        }

    }
}
