﻿/**
* 3/6/23
* CSC 153
* Max Cayton
* This program saves a file filled with however many random numbers the user requests.
*/
using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        int numberCount;
        StreamWriter outputFile;
        Random rand = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {            

            // Collects input from the User, then asks them where to save their file and what to name it
            try
            {
                numberCount = int.Parse(numCountTextBox.Text);

                // Sets default file extension as a text file
                numberSaveFileDialog.Filter = "Text Files | *.txt";
                numberSaveFileDialog.DefaultExt = "txt";

                if (numberSaveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    outputFile = File.CreateText(numberSaveFileDialog.FileName);

                    for (int i = 0; i < numberCount; i++)
                    {
                        outputFile.WriteLine(rand.Next(1, 101).ToString());
                    }

                    outputFile.Close();
                    numCountTextBox.Clear();
                }            
            }
            
            // Prevents the program from crashing if the user enters invalid input, or if something goes wrong with file handling
            catch
            {
                MessageBox.Show("Something went wrong, try again.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}