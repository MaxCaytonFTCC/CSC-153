﻿/**
* 2/28/2023
* CSC 153
* Max Cayton
* This program generates a random number for the user to guess.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        int userNum = -1;
        int answer = 0;
        int guessCount = 0;
       
        Random rand = new Random();

        public Form1()
        {
            // Initial Answer
            answer = rand.Next(101);            
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            // Collect Input & add to guesses
            int.TryParse(inputTextBox.Text, out userNum);
            guessCount++;
                // Check guess against answer
                if (userNum > answer)
                {
                    MessageBox.Show("Too high, try again.");
                }
                else if (userNum < answer)
                {
                    MessageBox.Show("Too low, try again.");
                }
                
                // Congratulate & Reset Game
                else
                {                
                    if (guessCount > 1)
                    {
                        MessageBox.Show("Congratulations, that is correct!\nIt took you " + guessCount.ToString() + " guesses to find it!");
                    }
                    else
                    {
                        MessageBox.Show("Congratulations, that is correct!\nIt took you " + guessCount.ToString() + " guess to find it!");
                    }
                    answer = rand.Next(101);
                    inputTextBox.Clear();
                    guessCount = 0;
                }
            
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}