﻿/**
* 3/13/23
* CSC 153
* Max Cayton
* This program takes seconds as input and calculates the distance in meters an object would have fallen in that time.
*/
using System;
using DistanceLibrary;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        int time;
        public Form1()
        {
            InitializeComponent();
        }

        // Perform Calculations & Handle Data
        private void submitButton_Click(object sender, EventArgs e)
        {
            distanceTextBox.Clear();
            int.TryParse(secondsTextBox.Text, out time);
            distanceTextBox.Text = DistanceCalculation.CalculateFallingDistance(time).ToString();
            secondsTextBox.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}