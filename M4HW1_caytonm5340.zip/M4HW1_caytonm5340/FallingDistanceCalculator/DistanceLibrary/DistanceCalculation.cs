﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistanceLibrary
{
    public class DistanceCalculation
    {       
        public static double CalculateFallingDistance(int time)
        {            
            return (0.5 * 9.8 * (time * time));
        }
    }
}
