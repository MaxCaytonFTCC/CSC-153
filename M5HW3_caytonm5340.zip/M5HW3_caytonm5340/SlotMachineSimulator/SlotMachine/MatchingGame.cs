﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SlotMachine
{
    public class MatchingGame
    {

        public static int[] GenerateSlotResult()
        {
            Random rand = new Random();
            int[] slotResult = new int[3];

            for (int i = 0; i < 3; i++)
            {
                slotResult[i] = rand.Next(10);
            }

            return slotResult;

        }

        public static int GetMatchCount(int[] slotResult)
        {

            int matchCount = 0;
            int currentSymbol = -1;

            for (int i = 0; i < slotResult.Length; i++)
            {
                currentSymbol = slotResult[i];

                for (int j = 0; j < slotResult.Length; j++)
                {
                    if (slotResult[j] == currentSymbol)
                    {
                        matchCount++;
                    }
                }                
                
                if (matchCount > 1)
                {
                    break;
                }
                else
                {
                    matchCount = 0;
                }

            }

            return matchCount;

        }

    }
}
