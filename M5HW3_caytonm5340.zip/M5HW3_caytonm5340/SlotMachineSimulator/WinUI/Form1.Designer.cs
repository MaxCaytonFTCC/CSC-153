﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.moneyTextBox = new System.Windows.Forms.TextBox();
            this.instructionLabel = new System.Windows.Forms.Label();
            this.spinButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.fruitImageList = new System.Windows.Forms.ImageList(this.components);
            this.firstSymbolPictureBox = new System.Windows.Forms.PictureBox();
            this.secondSymbolPictureBox = new System.Windows.Forms.PictureBox();
            this.thirdSymbolPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.firstSymbolPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondSymbolPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thirdSymbolPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // moneyTextBox
            // 
            this.moneyTextBox.Location = new System.Drawing.Point(249, 190);
            this.moneyTextBox.Name = "moneyTextBox";
            this.moneyTextBox.Size = new System.Drawing.Size(100, 26);
            this.moneyTextBox.TabIndex = 0;
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Location = new System.Drawing.Point(98, 196);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(145, 20);
            this.instructionLabel.TabIndex = 1;
            this.instructionLabel.Text = "Amount Inserted: $";
            // 
            // spinButton
            // 
            this.spinButton.Location = new System.Drawing.Point(102, 266);
            this.spinButton.Name = "spinButton";
            this.spinButton.Size = new System.Drawing.Size(88, 29);
            this.spinButton.TabIndex = 2;
            this.spinButton.Text = "Spin";
            this.spinButton.UseVisualStyleBackColor = true;
            this.spinButton.Click += new System.EventHandler(this.spinButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(267, 266);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(82, 29);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // fruitImageList
            // 
            this.fruitImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("fruitImageList.ImageStream")));
            this.fruitImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.fruitImageList.Images.SetKeyName(0, "Apple.bmp");
            this.fruitImageList.Images.SetKeyName(1, "Banana.bmp");
            this.fruitImageList.Images.SetKeyName(2, "Cherries.bmp");
            this.fruitImageList.Images.SetKeyName(3, "Grapes.bmp");
            this.fruitImageList.Images.SetKeyName(4, "Lemon.bmp");
            this.fruitImageList.Images.SetKeyName(5, "Lime.bmp");
            this.fruitImageList.Images.SetKeyName(6, "Orange.bmp");
            this.fruitImageList.Images.SetKeyName(7, "Pear.bmp");
            this.fruitImageList.Images.SetKeyName(8, "Strawberry.bmp");
            this.fruitImageList.Images.SetKeyName(9, "Watermelon.bmp");
            // 
            // firstSymbolPictureBox
            // 
            this.firstSymbolPictureBox.Location = new System.Drawing.Point(27, 21);
            this.firstSymbolPictureBox.Name = "firstSymbolPictureBox";
            this.firstSymbolPictureBox.Size = new System.Drawing.Size(128, 128);
            this.firstSymbolPictureBox.TabIndex = 4;
            this.firstSymbolPictureBox.TabStop = false;
            // 
            // secondSymbolPictureBox
            // 
            this.secondSymbolPictureBox.Location = new System.Drawing.Point(161, 21);
            this.secondSymbolPictureBox.Name = "secondSymbolPictureBox";
            this.secondSymbolPictureBox.Size = new System.Drawing.Size(128, 128);
            this.secondSymbolPictureBox.TabIndex = 5;
            this.secondSymbolPictureBox.TabStop = false;
            // 
            // thirdSymbolPictureBox
            // 
            this.thirdSymbolPictureBox.Location = new System.Drawing.Point(295, 21);
            this.thirdSymbolPictureBox.Name = "thirdSymbolPictureBox";
            this.thirdSymbolPictureBox.Size = new System.Drawing.Size(128, 128);
            this.thirdSymbolPictureBox.TabIndex = 6;
            this.thirdSymbolPictureBox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(441, 328);
            this.Controls.Add(this.thirdSymbolPictureBox);
            this.Controls.Add(this.secondSymbolPictureBox);
            this.Controls.Add(this.firstSymbolPictureBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.spinButton);
            this.Controls.Add(this.instructionLabel);
            this.Controls.Add(this.moneyTextBox);
            this.Name = "Form1";
            this.Text = "Slot Machine Simulator";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.firstSymbolPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.secondSymbolPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thirdSymbolPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox moneyTextBox;
        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.Button spinButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ImageList fruitImageList;
        private System.Windows.Forms.PictureBox firstSymbolPictureBox;
        private System.Windows.Forms.PictureBox secondSymbolPictureBox;
        private System.Windows.Forms.PictureBox thirdSymbolPictureBox;
    }
}

