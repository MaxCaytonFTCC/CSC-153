﻿/**
* 4/17/23
* CSC 153
* Max Cayton
* This program simulates a slot machine.
*/
using System;
using SlotMachine;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Default Images Before the Game is Played
            firstSymbolPictureBox.Image = fruitImageList.Images[0];
            secondSymbolPictureBox.Image = fruitImageList.Images[1];
            thirdSymbolPictureBox.Image = fruitImageList.Images[2];

        }

        private void spinButton_Click(object sender, EventArgs e)
        {
            // Gets the user's money
            int userMoney;
            int.TryParse(moneyTextBox.Text, out userMoney);

            // Gets the Result of the Spin & Displays the Graphics
            int[] slotResult = MatchingGame.GenerateSlotResult();
            firstSymbolPictureBox.Image = fruitImageList.Images[slotResult[0]];
            secondSymbolPictureBox.Image = fruitImageList.Images[slotResult[1]];
            thirdSymbolPictureBox.Image = fruitImageList.Images[slotResult[2]];

            // Calculate the Amount of Matches & How Much Money the User Won
            int matchCount = MatchingGame.GetMatchCount(slotResult);
            userMoney *= matchCount;
            MessageBox.Show("You won $"+userMoney.ToString());

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
