﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inputGroupBox = new System.Windows.Forms.GroupBox();
            this.rehabLabel = new System.Windows.Forms.Label();
            this.labLabel = new System.Windows.Forms.Label();
            this.surgicalLabel = new System.Windows.Forms.Label();
            this.medicationLabel = new System.Windows.Forms.Label();
            this.daysLabel = new System.Windows.Forms.Label();
            this.rehabTextBox = new System.Windows.Forms.TextBox();
            this.labTextBox = new System.Windows.Forms.TextBox();
            this.surgicalTextBox = new System.Windows.Forms.TextBox();
            this.medicationTextBox = new System.Windows.Forms.TextBox();
            this.daysTextBox = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.totalCostTextBox = new System.Windows.Forms.TextBox();
            this.outputLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.inputGroupBox.SuspendLayout();
            this.outputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // inputGroupBox
            // 
            this.inputGroupBox.Controls.Add(this.rehabLabel);
            this.inputGroupBox.Controls.Add(this.labLabel);
            this.inputGroupBox.Controls.Add(this.surgicalLabel);
            this.inputGroupBox.Controls.Add(this.medicationLabel);
            this.inputGroupBox.Controls.Add(this.daysLabel);
            this.inputGroupBox.Controls.Add(this.rehabTextBox);
            this.inputGroupBox.Controls.Add(this.labTextBox);
            this.inputGroupBox.Controls.Add(this.surgicalTextBox);
            this.inputGroupBox.Controls.Add(this.medicationTextBox);
            this.inputGroupBox.Controls.Add(this.daysTextBox);
            this.inputGroupBox.Controls.Add(this.submitButton);
            this.inputGroupBox.Location = new System.Drawing.Point(33, 49);
            this.inputGroupBox.Name = "inputGroupBox";
            this.inputGroupBox.Size = new System.Drawing.Size(349, 302);
            this.inputGroupBox.TabIndex = 0;
            this.inputGroupBox.TabStop = false;
            this.inputGroupBox.Text = "Input";
            // 
            // rehabLabel
            // 
            this.rehabLabel.AutoSize = true;
            this.rehabLabel.Location = new System.Drawing.Point(31, 202);
            this.rehabLabel.Name = "rehabLabel";
            this.rehabLabel.Size = new System.Drawing.Size(168, 20);
            this.rehabLabel.TabIndex = 10;
            this.rehabLabel.Text = "Enter Rehab Charges:";
            // 
            // labLabel
            // 
            this.labLabel.AutoSize = true;
            this.labLabel.Location = new System.Drawing.Point(49, 158);
            this.labLabel.Name = "labLabel";
            this.labLabel.Size = new System.Drawing.Size(123, 20);
            this.labLabel.TabIndex = 9;
            this.labLabel.Text = "Enter Lab Fees:";
            // 
            // surgicalLabel
            // 
            this.surgicalLabel.AutoSize = true;
            this.surgicalLabel.Location = new System.Drawing.Point(22, 112);
            this.surgicalLabel.Name = "surgicalLabel";
            this.surgicalLabel.Size = new System.Drawing.Size(177, 20);
            this.surgicalLabel.TabIndex = 8;
            this.surgicalLabel.Text = "Enter Surgical Charges:";
            // 
            // medicationLabel
            // 
            this.medicationLabel.AutoSize = true;
            this.medicationLabel.Location = new System.Drawing.Point(16, 67);
            this.medicationLabel.Name = "medicationLabel";
            this.medicationLabel.Size = new System.Drawing.Size(197, 20);
            this.medicationLabel.TabIndex = 7;
            this.medicationLabel.Text = "Enter Medication Charges:";
            this.medicationLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // daysLabel
            // 
            this.daysLabel.AutoSize = true;
            this.daysLabel.Location = new System.Drawing.Point(29, 28);
            this.daysLabel.Name = "daysLabel";
            this.daysLabel.Size = new System.Drawing.Size(170, 20);
            this.daysLabel.TabIndex = 6;
            this.daysLabel.Text = "Enter Number of Days:";
            this.daysLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rehabTextBox
            // 
            this.rehabTextBox.Location = new System.Drawing.Point(234, 199);
            this.rehabTextBox.Name = "rehabTextBox";
            this.rehabTextBox.Size = new System.Drawing.Size(100, 26);
            this.rehabTextBox.TabIndex = 5;
            // 
            // labTextBox
            // 
            this.labTextBox.Location = new System.Drawing.Point(234, 155);
            this.labTextBox.Name = "labTextBox";
            this.labTextBox.Size = new System.Drawing.Size(100, 26);
            this.labTextBox.TabIndex = 4;
            // 
            // surgicalTextBox
            // 
            this.surgicalTextBox.Location = new System.Drawing.Point(234, 109);
            this.surgicalTextBox.Name = "surgicalTextBox";
            this.surgicalTextBox.Size = new System.Drawing.Size(100, 26);
            this.surgicalTextBox.TabIndex = 3;
            // 
            // medicationTextBox
            // 
            this.medicationTextBox.Location = new System.Drawing.Point(234, 64);
            this.medicationTextBox.Name = "medicationTextBox";
            this.medicationTextBox.Size = new System.Drawing.Size(100, 26);
            this.medicationTextBox.TabIndex = 2;
            // 
            // daysTextBox
            // 
            this.daysTextBox.Location = new System.Drawing.Point(234, 22);
            this.daysTextBox.Name = "daysTextBox";
            this.daysTextBox.Size = new System.Drawing.Size(100, 26);
            this.daysTextBox.TabIndex = 1;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(255, 258);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(79, 35);
            this.submitButton.TabIndex = 0;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.totalCostTextBox);
            this.outputGroupBox.Controls.Add(this.outputLabel);
            this.outputGroupBox.Controls.Add(this.exitButton);
            this.outputGroupBox.Location = new System.Drawing.Point(401, 49);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(248, 158);
            this.outputGroupBox.TabIndex = 1;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Output";
            // 
            // totalCostTextBox
            // 
            this.totalCostTextBox.Location = new System.Drawing.Point(112, 41);
            this.totalCostTextBox.Name = "totalCostTextBox";
            this.totalCostTextBox.Size = new System.Drawing.Size(100, 26);
            this.totalCostTextBox.TabIndex = 2;
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.Location = new System.Drawing.Point(20, 41);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(85, 20);
            this.outputLabel.TabIndex = 1;
            this.outputLabel.Text = "Total Cost:";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(162, 106);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(80, 33);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(673, 389);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.inputGroupBox);
            this.Name = "Form1";
            this.Text = "Hospital Charges Calculator";
            this.inputGroupBox.ResumeLayout(false);
            this.inputGroupBox.PerformLayout();
            this.outputGroupBox.ResumeLayout(false);
            this.outputGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox inputGroupBox;
        private System.Windows.Forms.Label daysLabel;
        private System.Windows.Forms.TextBox rehabTextBox;
        private System.Windows.Forms.TextBox labTextBox;
        private System.Windows.Forms.TextBox surgicalTextBox;
        private System.Windows.Forms.TextBox medicationTextBox;
        private System.Windows.Forms.TextBox daysTextBox;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label medicationLabel;
        private System.Windows.Forms.Label rehabLabel;
        private System.Windows.Forms.Label labLabel;
        private System.Windows.Forms.Label surgicalLabel;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.TextBox totalCostTextBox;
    }
}

