﻿/**
* 3/20/23
* CSC 153
* Max Cayton
* This program calculates the total cost of a hospital visit.
*/
using System;
using HospitalLibrary;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {        
        decimal stayCharges = 0.0m;
        decimal totalMisc = 0.0m;
        decimal totalAll = 0.0m;

        // User Input Variables
        int daysCount;
        decimal medicationCharges;
        decimal surgicalCharges;
        decimal labFees;
        decimal rehabCharges;

        public Form1()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            // Collect & Parse Input
            int.TryParse(daysTextBox.Text, out daysCount);
            decimal.TryParse(medicationTextBox.Text, out medicationCharges);
            decimal.TryParse(surgicalTextBox.Text, out surgicalCharges);
            decimal.TryParse(labTextBox.Text, out labFees);
            decimal.TryParse(rehabTextBox.Text, out rehabCharges);

            stayCharges = HospitalCalculator.CalcStayCharges(daysCount);

            totalMisc = HospitalCalculator.CalcMiscCharges(medicationCharges, surgicalCharges, labFees, rehabCharges);

            totalAll = HospitalCalculator.CalcTotalCharges(totalMisc,stayCharges);

            totalCostTextBox.Text = totalAll.ToString("c");

            // Reset Text Boxes
            daysTextBox.Clear();
            medicationTextBox.Clear();
            surgicalTextBox.Clear();
            labTextBox.Clear();
            rehabTextBox.Clear();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
