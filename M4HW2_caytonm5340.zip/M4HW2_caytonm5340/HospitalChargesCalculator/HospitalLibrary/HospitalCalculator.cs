﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalLibrary
{
    public class HospitalCalculator
    {
        public static decimal CalcStayCharges(int daysCount)
        {
            return (daysCount * 350.0m);
        }

        public static decimal CalcMiscCharges(decimal medicationCharges, decimal surgicalCharges, decimal labFees, decimal rehabCharges)
        {
            return (medicationCharges + surgicalCharges + labFees + rehabCharges);
        }

        public static decimal CalcTotalCharges(decimal totalMisc, decimal stayCharges)
        {
            return (totalMisc + stayCharges);
        }
    }
}
