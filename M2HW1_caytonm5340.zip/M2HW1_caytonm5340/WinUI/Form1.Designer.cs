﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstColorGroupBox = new System.Windows.Forms.GroupBox();
            this.firstColorYellowRadioButton = new System.Windows.Forms.RadioButton();
            this.firstColorBlueRadioButton = new System.Windows.Forms.RadioButton();
            this.firstColorRedRadioButton = new System.Windows.Forms.RadioButton();
            this.secondColorGroupBox = new System.Windows.Forms.GroupBox();
            this.secondColorYellowRadioButton = new System.Windows.Forms.RadioButton();
            this.secondColorBlueRadioButton = new System.Windows.Forms.RadioButton();
            this.secondColorRedRadioButton = new System.Windows.Forms.RadioButton();
            this.mixButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.firstColorGroupBox.SuspendLayout();
            this.secondColorGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // firstColorGroupBox
            // 
            this.firstColorGroupBox.Controls.Add(this.firstColorYellowRadioButton);
            this.firstColorGroupBox.Controls.Add(this.firstColorBlueRadioButton);
            this.firstColorGroupBox.Controls.Add(this.firstColorRedRadioButton);
            this.firstColorGroupBox.Location = new System.Drawing.Point(55, 54);
            this.firstColorGroupBox.Name = "firstColorGroupBox";
            this.firstColorGroupBox.Size = new System.Drawing.Size(310, 232);
            this.firstColorGroupBox.TabIndex = 0;
            this.firstColorGroupBox.TabStop = false;
            this.firstColorGroupBox.Text = "Select the First Color";
            // 
            // firstColorYellowRadioButton
            // 
            this.firstColorYellowRadioButton.AutoSize = true;
            this.firstColorYellowRadioButton.Location = new System.Drawing.Point(115, 163);
            this.firstColorYellowRadioButton.Name = "firstColorYellowRadioButton";
            this.firstColorYellowRadioButton.Size = new System.Drawing.Size(80, 24);
            this.firstColorYellowRadioButton.TabIndex = 2;
            this.firstColorYellowRadioButton.TabStop = true;
            this.firstColorYellowRadioButton.Text = "Yellow";
            this.firstColorYellowRadioButton.UseVisualStyleBackColor = true;
            // 
            // firstColorBlueRadioButton
            // 
            this.firstColorBlueRadioButton.AutoSize = true;
            this.firstColorBlueRadioButton.Location = new System.Drawing.Point(115, 107);
            this.firstColorBlueRadioButton.Name = "firstColorBlueRadioButton";
            this.firstColorBlueRadioButton.Size = new System.Drawing.Size(66, 24);
            this.firstColorBlueRadioButton.TabIndex = 1;
            this.firstColorBlueRadioButton.TabStop = true;
            this.firstColorBlueRadioButton.Text = "Blue";
            this.firstColorBlueRadioButton.UseVisualStyleBackColor = true;
            // 
            // firstColorRedRadioButton
            // 
            this.firstColorRedRadioButton.AutoSize = true;
            this.firstColorRedRadioButton.Location = new System.Drawing.Point(115, 54);
            this.firstColorRedRadioButton.Name = "firstColorRedRadioButton";
            this.firstColorRedRadioButton.Size = new System.Drawing.Size(64, 24);
            this.firstColorRedRadioButton.TabIndex = 0;
            this.firstColorRedRadioButton.TabStop = true;
            this.firstColorRedRadioButton.Text = "Red";
            this.firstColorRedRadioButton.UseVisualStyleBackColor = true;
            // 
            // secondColorGroupBox
            // 
            this.secondColorGroupBox.Controls.Add(this.secondColorYellowRadioButton);
            this.secondColorGroupBox.Controls.Add(this.secondColorBlueRadioButton);
            this.secondColorGroupBox.Controls.Add(this.secondColorRedRadioButton);
            this.secondColorGroupBox.Location = new System.Drawing.Point(421, 54);
            this.secondColorGroupBox.Name = "secondColorGroupBox";
            this.secondColorGroupBox.Size = new System.Drawing.Size(310, 232);
            this.secondColorGroupBox.TabIndex = 1;
            this.secondColorGroupBox.TabStop = false;
            this.secondColorGroupBox.Text = "Select the Second Color";
            // 
            // secondColorYellowRadioButton
            // 
            this.secondColorYellowRadioButton.AutoSize = true;
            this.secondColorYellowRadioButton.Location = new System.Drawing.Point(121, 163);
            this.secondColorYellowRadioButton.Name = "secondColorYellowRadioButton";
            this.secondColorYellowRadioButton.Size = new System.Drawing.Size(80, 24);
            this.secondColorYellowRadioButton.TabIndex = 5;
            this.secondColorYellowRadioButton.TabStop = true;
            this.secondColorYellowRadioButton.Text = "Yellow";
            this.secondColorYellowRadioButton.UseVisualStyleBackColor = true;
            // 
            // secondColorBlueRadioButton
            // 
            this.secondColorBlueRadioButton.AutoSize = true;
            this.secondColorBlueRadioButton.Location = new System.Drawing.Point(121, 107);
            this.secondColorBlueRadioButton.Name = "secondColorBlueRadioButton";
            this.secondColorBlueRadioButton.Size = new System.Drawing.Size(66, 24);
            this.secondColorBlueRadioButton.TabIndex = 4;
            this.secondColorBlueRadioButton.TabStop = true;
            this.secondColorBlueRadioButton.Text = "Blue";
            this.secondColorBlueRadioButton.UseVisualStyleBackColor = true;
            // 
            // secondColorRedRadioButton
            // 
            this.secondColorRedRadioButton.AutoSize = true;
            this.secondColorRedRadioButton.Location = new System.Drawing.Point(121, 54);
            this.secondColorRedRadioButton.Name = "secondColorRedRadioButton";
            this.secondColorRedRadioButton.Size = new System.Drawing.Size(64, 24);
            this.secondColorRedRadioButton.TabIndex = 3;
            this.secondColorRedRadioButton.TabStop = true;
            this.secondColorRedRadioButton.Text = "Red";
            this.secondColorRedRadioButton.UseVisualStyleBackColor = true;
            // 
            // mixButton
            // 
            this.mixButton.Location = new System.Drawing.Point(289, 322);
            this.mixButton.Name = "mixButton";
            this.mixButton.Size = new System.Drawing.Size(76, 29);
            this.mixButton.TabIndex = 2;
            this.mixButton.Text = "Mix";
            this.mixButton.UseVisualStyleBackColor = true;
            this.mixButton.Click += new System.EventHandler(this.mixButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(421, 322);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(76, 29);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(777, 394);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.mixButton);
            this.Controls.Add(this.secondColorGroupBox);
            this.Controls.Add(this.firstColorGroupBox);
            this.Name = "Form1";
            this.Text = "Color Mixer";
            this.firstColorGroupBox.ResumeLayout(false);
            this.firstColorGroupBox.PerformLayout();
            this.secondColorGroupBox.ResumeLayout(false);
            this.secondColorGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox firstColorGroupBox;
        private System.Windows.Forms.RadioButton firstColorYellowRadioButton;
        private System.Windows.Forms.RadioButton firstColorBlueRadioButton;
        private System.Windows.Forms.RadioButton firstColorRedRadioButton;
        private System.Windows.Forms.GroupBox secondColorGroupBox;
        private System.Windows.Forms.RadioButton secondColorYellowRadioButton;
        private System.Windows.Forms.RadioButton secondColorBlueRadioButton;
        private System.Windows.Forms.RadioButton secondColorRedRadioButton;
        private System.Windows.Forms.Button mixButton;
        private System.Windows.Forms.Button exitButton;
    }
}

