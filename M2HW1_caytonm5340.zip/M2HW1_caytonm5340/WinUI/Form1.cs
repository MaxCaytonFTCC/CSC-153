﻿/**
* 2/7/2023
* CSC 153
* Max Cayton
* This program takes two colors as input through radio buttons and changes the color of the UI's background to the resultant color of mixing the aforementioned inputs.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {

        private string finalColor;

        public Form1()
        {
            InitializeComponent();
        }

        
        private void mixButton_Click(object sender, EventArgs e)
        {
            // Determines the final color based on the conditions of the radio buttons
            if (firstColorRedRadioButton.Checked == true)
            {
                if (secondColorBlueRadioButton.Checked == true)
                {
                    finalColor = "Purple";
                }

                else if (secondColorYellowRadioButton.Checked == true)
                {
                    finalColor = "Orange";
                }

                else
                {
                    finalColor = "Red";
                }

            }

            else if (firstColorBlueRadioButton.Checked == true)
            {
                if (secondColorRedRadioButton.Checked == true)
                {
                    finalColor = "Purple";
                }

                else if (secondColorYellowRadioButton.Checked == true)
                {
                    finalColor = "Green";
                }

                else
                {
                    finalColor = "Blue";
                }
            }

            else if (firstColorYellowRadioButton.Checked == true)
            {
                if (secondColorRedRadioButton.Checked == true)
                {
                    finalColor = "Orange";
                }

                else if (secondColorBlueRadioButton.Checked == true)
                {
                    finalColor = "Green";
                }

                else
                {
                    finalColor = "Yellow";
                }

            }

            // Applies the change of color based on the final color
            switch (finalColor)
            {
                case "Red":
                    BackColor = Color.Red;
                    break;

                case "Blue":
                    BackColor = Color.Blue;
                    break;

                case "Yellow":
                    BackColor = Color.Yellow;
                    break;

                case "Purple":
                    BackColor = Color.Purple;
                    break;

                case "Green":
                    BackColor = Color.Green;
                    break;

                case "Orange":
                    BackColor = Color.Orange;
                    break;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
