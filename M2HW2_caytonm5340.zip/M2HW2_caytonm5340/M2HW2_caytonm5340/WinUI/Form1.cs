﻿/**
* 2/13/23
* CSC 153
* Max Cayton
* This program provides a number of dollars and asks the user to attempt split it into cents.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinUI
{
    public partial class Form1 : Form
    {
        int penniesCount = 0, nickelsCount = 0, dimesCount = 0, quartersCount = 0;
        string congratsMessage = "Congratulations, you win!", greaterMessage = "Your answer is too high!", lesserMessage = "Your answer is too low!";
        double sum = 0.0f, dollarCount = 0.0f;
        Random rand = new Random();

        public Form1()
        {
            InitializeComponent();
            // Starts the Dollars with an initial value
            dollarCount = rand.Next(1, 10);
            dollarsTextBox.Text = dollarCount.ToString("c");
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            // Gathers Input
            int.TryParse(penniesTextBox.Text, out penniesCount);
            int.TryParse(nickelsTextBox.Text, out nickelsCount);
            int.TryParse(dimesTextBox.Text, out dimesCount);
            int.TryParse(quartersTextBox.Text, out quartersCount);

            // Calculates the Sum and Checks it Against the Dollars
            sum = (penniesCount * 0.01) + (nickelsCount * 0.05) + (dimesCount * 0.10) + (quartersCount * 0.25);

            if (sum > dollarCount)
            {
                outputTextBox.Text = greaterMessage;
            }
            else if (sum < dollarCount)
            {
                outputTextBox.Text = lesserMessage;
            }
            else
            {
                outputTextBox.Text = congratsMessage;
            }

        }

        
        private void replayButton_Click(object sender, EventArgs e)
        {
        // Resets The Game
            penniesCount = 0;
            nickelsCount = 0;
            dimesCount = 0;
            quartersCount = 0;
            sum = 0;

            penniesTextBox.Clear();
            nickelsTextBox.Clear();
            dimesTextBox.Clear();
            quartersTextBox.Clear();
            outputTextBox.Clear();

            dollarCount = rand.Next(1, 10);
            dollarsTextBox.Text = dollarCount.ToString("c");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
