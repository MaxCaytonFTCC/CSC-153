﻿
namespace WinUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.penniesTextBox = new System.Windows.Forms.TextBox();
            this.nickelsTextBox = new System.Windows.Forms.TextBox();
            this.dimesTextBox = new System.Windows.Forms.TextBox();
            this.quartersTextBox = new System.Windows.Forms.TextBox();
            this.penniesLabel = new System.Windows.Forms.Label();
            this.nickelsLabel = new System.Windows.Forms.Label();
            this.dimesLabel = new System.Windows.Forms.Label();
            this.quartersLabel = new System.Windows.Forms.Label();
            this.submitButton = new System.Windows.Forms.Button();
            this.centsGroupBox = new System.Windows.Forms.GroupBox();
            this.dollarsGroupBox = new System.Windows.Forms.GroupBox();
            this.dollarsTextBox = new System.Windows.Forms.TextBox();
            this.dollarLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            this.outputGroupBox = new System.Windows.Forms.GroupBox();
            this.replayButton = new System.Windows.Forms.Button();
            this.outputTextBox = new System.Windows.Forms.TextBox();
            this.centsGroupBox.SuspendLayout();
            this.dollarsGroupBox.SuspendLayout();
            this.outputGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // penniesTextBox
            // 
            this.penniesTextBox.Location = new System.Drawing.Point(221, 54);
            this.penniesTextBox.Name = "penniesTextBox";
            this.penniesTextBox.Size = new System.Drawing.Size(100, 26);
            this.penniesTextBox.TabIndex = 0;
            // 
            // nickelsTextBox
            // 
            this.nickelsTextBox.Location = new System.Drawing.Point(221, 99);
            this.nickelsTextBox.Name = "nickelsTextBox";
            this.nickelsTextBox.Size = new System.Drawing.Size(100, 26);
            this.nickelsTextBox.TabIndex = 1;
            // 
            // dimesTextBox
            // 
            this.dimesTextBox.Location = new System.Drawing.Point(221, 149);
            this.dimesTextBox.Name = "dimesTextBox";
            this.dimesTextBox.Size = new System.Drawing.Size(100, 26);
            this.dimesTextBox.TabIndex = 2;
            // 
            // quartersTextBox
            // 
            this.quartersTextBox.Location = new System.Drawing.Point(221, 193);
            this.quartersTextBox.Name = "quartersTextBox";
            this.quartersTextBox.Size = new System.Drawing.Size(100, 26);
            this.quartersTextBox.TabIndex = 3;
            // 
            // penniesLabel
            // 
            this.penniesLabel.AutoSize = true;
            this.penniesLabel.Location = new System.Drawing.Point(18, 54);
            this.penniesLabel.Name = "penniesLabel";
            this.penniesLabel.Size = new System.Drawing.Size(191, 20);
            this.penniesLabel.TabIndex = 4;
            this.penniesLabel.Text = "Enter Number of Pennies:";
            // 
            // nickelsLabel
            // 
            this.nickelsLabel.AutoSize = true;
            this.nickelsLabel.Location = new System.Drawing.Point(18, 102);
            this.nickelsLabel.Name = "nickelsLabel";
            this.nickelsLabel.Size = new System.Drawing.Size(184, 20);
            this.nickelsLabel.TabIndex = 5;
            this.nickelsLabel.Text = "Enter Number of Nickels:";
            // 
            // dimesLabel
            // 
            this.dimesLabel.AutoSize = true;
            this.dimesLabel.Location = new System.Drawing.Point(18, 152);
            this.dimesLabel.Name = "dimesLabel";
            this.dimesLabel.Size = new System.Drawing.Size(179, 20);
            this.dimesLabel.TabIndex = 6;
            this.dimesLabel.Text = "Enter Number of Dimes:";
            // 
            // quartersLabel
            // 
            this.quartersLabel.AutoSize = true;
            this.quartersLabel.Location = new System.Drawing.Point(18, 196);
            this.quartersLabel.Name = "quartersLabel";
            this.quartersLabel.Size = new System.Drawing.Size(196, 20);
            this.quartersLabel.TabIndex = 7;
            this.quartersLabel.Text = "Enter Number of Quarters:";
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(221, 260);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(100, 32);
            this.submitButton.TabIndex = 8;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // centsGroupBox
            // 
            this.centsGroupBox.Controls.Add(this.submitButton);
            this.centsGroupBox.Controls.Add(this.quartersLabel);
            this.centsGroupBox.Controls.Add(this.dimesLabel);
            this.centsGroupBox.Controls.Add(this.nickelsLabel);
            this.centsGroupBox.Controls.Add(this.penniesLabel);
            this.centsGroupBox.Controls.Add(this.quartersTextBox);
            this.centsGroupBox.Controls.Add(this.dimesTextBox);
            this.centsGroupBox.Controls.Add(this.nickelsTextBox);
            this.centsGroupBox.Controls.Add(this.penniesTextBox);
            this.centsGroupBox.Location = new System.Drawing.Point(43, 52);
            this.centsGroupBox.Name = "centsGroupBox";
            this.centsGroupBox.Size = new System.Drawing.Size(374, 357);
            this.centsGroupBox.TabIndex = 0;
            this.centsGroupBox.TabStop = false;
            this.centsGroupBox.Text = "Cents";
            // 
            // dollarsGroupBox
            // 
            this.dollarsGroupBox.Controls.Add(this.dollarsTextBox);
            this.dollarsGroupBox.Controls.Add(this.dollarLabel);
            this.dollarsGroupBox.Location = new System.Drawing.Point(444, 52);
            this.dollarsGroupBox.Name = "dollarsGroupBox";
            this.dollarsGroupBox.Size = new System.Drawing.Size(322, 137);
            this.dollarsGroupBox.TabIndex = 1;
            this.dollarsGroupBox.TabStop = false;
            this.dollarsGroupBox.Text = "Dollars";
            // 
            // dollarsTextBox
            // 
            this.dollarsTextBox.Location = new System.Drawing.Point(111, 81);
            this.dollarsTextBox.Name = "dollarsTextBox";
            this.dollarsTextBox.Size = new System.Drawing.Size(100, 26);
            this.dollarsTextBox.TabIndex = 1;
            // 
            // dollarLabel
            // 
            this.dollarLabel.AutoSize = true;
            this.dollarLabel.Location = new System.Drawing.Point(16, 41);
            this.dollarLabel.Name = "dollarLabel";
            this.dollarLabel.Size = new System.Drawing.Size(291, 20);
            this.dollarLabel.TabIndex = 0;
            this.dollarLabel.Text = "Split This Value Into Change on the Left";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(222, 99);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(85, 34);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // outputGroupBox
            // 
            this.outputGroupBox.Controls.Add(this.replayButton);
            this.outputGroupBox.Controls.Add(this.outputTextBox);
            this.outputGroupBox.Controls.Add(this.exitButton);
            this.outputGroupBox.Location = new System.Drawing.Point(444, 233);
            this.outputGroupBox.Name = "outputGroupBox";
            this.outputGroupBox.Size = new System.Drawing.Size(322, 176);
            this.outputGroupBox.TabIndex = 3;
            this.outputGroupBox.TabStop = false;
            this.outputGroupBox.Text = "Output";
            // 
            // replayButton
            // 
            this.replayButton.Location = new System.Drawing.Point(111, 99);
            this.replayButton.Name = "replayButton";
            this.replayButton.Size = new System.Drawing.Size(102, 34);
            this.replayButton.TabIndex = 4;
            this.replayButton.Text = "Play Again";
            this.replayButton.UseVisualStyleBackColor = true;
            this.replayButton.Click += new System.EventHandler(this.replayButton_Click);
            // 
            // outputTextBox
            // 
            this.outputTextBox.Location = new System.Drawing.Point(20, 40);
            this.outputTextBox.Name = "outputTextBox";
            this.outputTextBox.Size = new System.Drawing.Size(287, 26);
            this.outputTextBox.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(833, 471);
            this.Controls.Add(this.outputGroupBox);
            this.Controls.Add(this.dollarsGroupBox);
            this.Controls.Add(this.centsGroupBox);
            this.Name = "Form1";
            this.Text = "Change For A Dollar Game";
            this.centsGroupBox.ResumeLayout(false);
            this.centsGroupBox.PerformLayout();
            this.dollarsGroupBox.ResumeLayout(false);
            this.dollarsGroupBox.PerformLayout();
            this.outputGroupBox.ResumeLayout(false);
            this.outputGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox penniesTextBox;
        private System.Windows.Forms.TextBox nickelsTextBox;
        private System.Windows.Forms.TextBox dimesTextBox;
        private System.Windows.Forms.TextBox quartersTextBox;
        private System.Windows.Forms.Label penniesLabel;
        private System.Windows.Forms.Label nickelsLabel;
        private System.Windows.Forms.Label dimesLabel;
        private System.Windows.Forms.Label quartersLabel;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.GroupBox centsGroupBox;
        private System.Windows.Forms.GroupBox dollarsGroupBox;
        private System.Windows.Forms.TextBox dollarsTextBox;
        private System.Windows.Forms.Label dollarLabel;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.GroupBox outputGroupBox;
        private System.Windows.Forms.Button replayButton;
        private System.Windows.Forms.TextBox outputTextBox;
    }
}

