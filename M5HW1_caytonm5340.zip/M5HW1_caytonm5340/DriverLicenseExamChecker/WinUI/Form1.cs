﻿using System;
using System.IO;
using Exam;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DriverLicenseExamChecker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void openExamButton_Click(object sender, EventArgs e)
        {            
            // Open a .txt file with open file dialog (example files provided in solution file)
            try
            {
                StreamReader inputFile;

                if (examOpenFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // Read data and assign it to array
                    inputFile = File.OpenText(examOpenFileDialog.FileName);

                    string[] studentAnswers = new string[20];

                    int index = 0;

                    while (index < studentAnswers.Length && !inputFile.EndOfStream)
                    {
                        studentAnswers[index] = inputFile.ReadLine();
                        index++;
                    }

                    inputFile.Close();
                   
                    List<string> incorrect = new List<string>();

                    int incorrectCount = DrivingExam.CheckAnswers(studentAnswers,incorrect);

                    // Display Which Questions Were Incorrect In the ListBox
                    incorrectQuestionsListBox.Items.Clear();

                    foreach (string ans in incorrect)
                    {
                        incorrectQuestionsListBox.Items.Add(ans);
                    }

                    if (incorrectCount > 5)
                    {
                        MessageBox.Show("You did not pass.\nCorrect Answers: " + (20 - incorrectCount) + "\nIncorrect Answers: " + (incorrectCount));                        
                    }
                    else
                    {
                        MessageBox.Show("Congratulations, you passed!\nCorrect Answers: " + (20 - incorrectCount) + "\nIncorrect Answers: " + (incorrectCount));
                    }

                }
            }

            catch
            {
                MessageBox.Show("Something Went Wrong, Try Again.");
            }


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
