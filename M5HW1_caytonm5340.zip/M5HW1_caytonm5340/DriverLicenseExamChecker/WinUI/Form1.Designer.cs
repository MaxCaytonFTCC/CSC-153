﻿
namespace DriverLicenseExamChecker
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.examOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.examLabel = new System.Windows.Forms.Label();
            this.openExamButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.incorrectQuestionsListBox = new System.Windows.Forms.ListBox();
            this.incorrectQuestionsLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // examLabel
            // 
            this.examLabel.AutoSize = true;
            this.examLabel.Location = new System.Drawing.Point(23, 32);
            this.examLabel.Name = "examLabel";
            this.examLabel.Size = new System.Drawing.Size(179, 40);
            this.examLabel.TabIndex = 0;
            this.examLabel.Text = "Open An Exam File \r\nTo Check Your Answers";
            this.examLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // openExamButton
            // 
            this.openExamButton.Location = new System.Drawing.Point(208, 39);
            this.openExamButton.Name = "openExamButton";
            this.openExamButton.Size = new System.Drawing.Size(82, 33);
            this.openExamButton.TabIndex = 1;
            this.openExamButton.Text = "Open";
            this.openExamButton.UseVisualStyleBackColor = true;
            this.openExamButton.Click += new System.EventHandler(this.openExamButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(620, 377);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(81, 33);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // incorrectQuestionsListBox
            // 
            this.incorrectQuestionsListBox.FormattingEnabled = true;
            this.incorrectQuestionsListBox.ItemHeight = 20;
            this.incorrectQuestionsListBox.Location = new System.Drawing.Point(326, 72);
            this.incorrectQuestionsListBox.Name = "incorrectQuestionsListBox";
            this.incorrectQuestionsListBox.Size = new System.Drawing.Size(315, 264);
            this.incorrectQuestionsListBox.TabIndex = 3;
            // 
            // incorrectQuestionsLabel
            // 
            this.incorrectQuestionsLabel.AutoSize = true;
            this.incorrectQuestionsLabel.Location = new System.Drawing.Point(322, 45);
            this.incorrectQuestionsLabel.Name = "incorrectQuestionsLabel";
            this.incorrectQuestionsLabel.Size = new System.Drawing.Size(290, 20);
            this.incorrectQuestionsLabel.TabIndex = 4;
            this.incorrectQuestionsLabel.Text = "Question Numbers That Were Incorrect:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(716, 428);
            this.Controls.Add(this.incorrectQuestionsLabel);
            this.Controls.Add(this.incorrectQuestionsListBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.openExamButton);
            this.Controls.Add(this.examLabel);
            this.Name = "Form1";
            this.Text = "Driver\'s License Exam Checker";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog examOpenFileDialog;
        private System.Windows.Forms.Label examLabel;
        private System.Windows.Forms.Button openExamButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox incorrectQuestionsListBox;
        private System.Windows.Forms.Label incorrectQuestionsLabel;
    }
}

