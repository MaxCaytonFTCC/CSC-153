﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam
{
    public class DrivingExam
    {
        public static int CheckAnswers(string[] studentAnswers, List<string> qList)
        {
            string[] correctAnswers = { "B", "D", "A", "A", "C", "A", "B", "A", "C", "D", "B", "C", "D", "A", "D", "C", "C", "B", "D", "A" };

            int incorrectCount = 0;

            for (int i = 0; i < correctAnswers.Length; i++)
            {
                if (studentAnswers[i] != correctAnswers[i])
                {
                    incorrectCount += 1;
                    qList.Add((i + 1).ToString());
                }
            }

            return incorrectCount;

        }
    }
}